// Copyright:
//	Copyritgh (2012) Aur�lien Ribes, CNRM-GAME, M�t�o France - CNRS
// 
// References:
// 	Ribes A., S. Planton, L. Terray (2012) Regularised optimal fingerprint for attribution. Part I: method, properties and idealised analysis. Climate dynamics, submitted. 
//	Ribes A., J.-M. Aza�s, S. Planton (2009) Adaptation of the optimal fingerprint method for climate change detection using a well-conditioned covariance matrix estimate. Climate dynamics, 33(5), 707-722, doi:10.1007/s00382-009-0561-4.
//	Allen M.A. and P.A. Stott (2003) Estimating signal amplitude in optimal fingerprinting, part i: theory (thereafter AS03).
//	Allen M.A. and S.F.B. Tett (1999) Checking for model consistency in optimal fingerprinting (thereafter AT99).
// 
// Description:
//	Main script for applying the Regularised Optimal Fingerprint (ROF) method for attribution. This script includes : I/O management, some steps of data pre-processing, statistical computations under OLS or TLS. The main result is provided as the estimated scaling factors, with the corresponding confidence intervals. 
//
// Inputs / Outputs and additional information: a short scientific documentation is provided in a .pdf file. Input / Outputs are described there, with some additional information about these programs. 
// 
// Contact:
//	aurelien.ribes@meteo.fr	(caution: hard anti-spam filter; in case of no response, go to my personal webpage).



// Scilab stuff
clear
lines(0);
stacksize(2*10^8);

// Compilation of subroutines
exec("extract_Z2.sci");
exec("Creg.sci");
exec("speco.sci");
exec("proj_FullRank.sci");
exec("total_wave_number.sci");
exec("tls.sci");
exec("consist_mc_tls.sci");
exec("gke.sci");



/////////////////
//   Options   //
/////////////////

// Type of regression
reg = '';		// 'OLS' or 'TLS'

// Spherical harmonics truncation
Trunc = ;

// Formule_IC_TLS: the formula used for computing confidence intervals in TLS
//	"AS03"	: the formula provided by Allen & Stott (2003)
//	"ODP"	: the formula implemented in Optimal Detection Package (in Nov 2011)
Formule_IC_TLS = "";

// Cons_test: the null-distribution used in the Residual Consistency Check (only the computation of the p-value will be impacted)
//	In OLS, this may be:
//		OLS_AT99: the formula provided by Allen & Tett (1999),
//		OLS_Corr: the formula provided by Ribes et al. (2012).
//	In TLS, this may be:
//		AS03: the null-distribution parametric formula provided by Allen & Stott (2003),
//		MC: Null-distribution evaluated via Monte-Carlo simulations (Ribes et al., 2012).
Cons_test = "";
N_cons_mc = 1000;	// The number of Monte-Carlo simulations performed (useful if Cons_test="MC"). 

// NbTs: Number of Time steps
NbTs = ;

// File containing observed data
file_obs = "";

// Files containing each pattern data
nom_fich_X = ["",""];
Proj = [];		// Which forcings in each simulation... See Scientific documentation, Section 3.1, "Whit is P ?"
nb_runs_X = [,];	// Number of runs used for evaluated each response pattern.
nb_forcings = length(nb_runs_X);


// File containing unforced data (eg: outputs from control runs)
nom_fich_ctl = "";
frac_Z2 = .5;			// fraction of data used in Z2 (the remaining is used in Z1)	[see extract_Z2.sci]
sampling_name = "regular";	// 'regular' (recommended),'random', or 'segment'		[see extract_Z2.sci]


N_spa = (Trunc+1)^2;	// Spatial dimension
N_st = N_spa * NbTs;	// Spatio_temporal dimension (ie dimension of y)



////////////////////////////////////
//   Inputs and pre-processing    //
////////////////////////////////////


//  Observations 
//---------------
fo=file("open",file_obs,"old");
y = read(fo,N_st,1);
file("close",fo);


//  Patterns x 
//-------------
I = max(size(nom_fich_X));
X=zeros(N_st,I);
for i=1:I
  fg = file("open",nom_fich_X(i),"old");
  X(:,i) = read(fg,N_st,1);
  file("close",fg);
end


//  Samples Zi : Evaluation of internal variability
//--------------------------------------------------
fv=file("open",nom_fich_ctl,"old");
epsil_tmp = read(fv,-1,1);
file("close",fv);

nle = length(epsil_tmp);
NZ = nle/N_st; 
if NZ ~= floor(NZ) then disp("Error reading the sample Z"); return; end
Z = matrix(epsil_tmp,N_st,NZ);

// Z1 and Z2 are taken from Z
Ind_Z2 = extract_Z2(sampling_name, NZ, frac_Z2);
Z1 = Z (:,~Ind_Z2);
Z2 = Z (:,Ind_Z2==1);


//  Pre-processing
//-----------------

// Weighting of spherical harmonics (cf Stott & Tett, 1998).
l = total_wave_number(Trunc);
p = 1 ./ sqrt(2*l-1);
Pml = diag(matrix(p*ones(1,NbTs),N_st,1));
y = Pml*y;
Z1 = Pml*Z1;
Z2 = Pml*Z2;
X = Pml*X;

// Removing of useless dimensions (equivalent to remove one time step; see scientific documentation, Section 2)
N_red = N_st - N_spa;	// Spatio-temporal dimension after reduction
U = proj_FullRank(NbTs,N_spa); 
// Project all input data
yc = U*y; Z1c = U*Z1; Z2c = U*Z2; Xc = U*X;



//////////////////////////////////
//    Statistical estimation    //
//////////////////////////////////


// Regularised covariance matrix :
Cf = Creg(Z1c');

Cf1 = real(Cf^(-1));
Cf12 = real(Cf^(-1/2));
Cfp12 = real(Cf^(1/2));


select reg
case 'OLS' then
  pv_consist = %nan;
  Ft = ( (Xc'*Cf1*Xc)^(-1) * Xc'*Cf1 )';
  beta_hat = yc' * Ft * Proj';

  // 1-D confidence intervals
  NZ2 = size(Z2c,2);
  Var_valid = Z2c*Z2c' / NZ2;
  Var_beta_hat = Proj * Ft' * Var_valid * Ft * Proj';
  beta_hat_inf(:) = beta_hat - cdft("T",NZ2,.95,.05) * sqrt( diag(Var_beta_hat)' );
  beta_hat_sup(:) = beta_hat + cdft("T",NZ2,.95,.05) * sqrt( diag(Var_beta_hat)' );

  // Consistency check :
  disp("Residual Consistency Check")
  epsilon = yc - Xc*Proj^(-1)*beta_hat';
  select Cons_test
  case "OLS_AT99"	// Formula provided by Allen & Tett (1999)
    d_cons = epsilon' *pinv(Var_valid)* epsilon / ( N_red-I);
    [rien,pv_cons] = cdff("PQ",d_cons,N_red-I,NZ2);
  case "OLS_Corr"	// Hotelling Formula
    d_cons = epsilon' *pinv(Var_valid)* epsilon / (NZ2*(N_red-I)) * (NZ2 - N_red +1);
    if NZ2-N_red+1 > 0 then
      [rien,pv_cons] = cdff("PQ",d_cons,N_red-I,NZ2 - N_red +1);
    else
      pv_cons = %nan;
    end
  else
    disp("Unknown Cons_test : "+Cons_test);
  end

case 'TLS' then
  [c0,c1,c2, d_cons, X_tilde_white, Y_tilde_white] = tls( Xc' * Cf12, yc' * Cf12, Z2c' * Cf12, nb_runs_X, Proj, Formule_IC_TLS);
  X_tilde = Cfp12 * X_tilde_white';
  Y_tilde = Cfp12 * Y_tilde_white';
  beta_hat = c0';
  beta_hat_inf = c1';
  beta_hat_sup = c2';

  // Consistency check
  disp("Residual Consistency Check");
  NZ1 = size(Z1c,2);
  NZ2 = size(Z2c,2);
  select Cons_test
  case "MC" then	// Null-distribution sampled via Monte-Carlo simulations
  // Note: input data here need to be pre-processed, centered, etc.
    // First, simulate random variables following the null-distribution
    d_H0_cons = consist_mc_tls(Cf,Xc,nb_runs_X,NZ1,NZ2,N_cons_mc,Formule_IC_TLS);
    // Evaluate the p-value from the H0 sample (this uses gke = gaussian kernel estimate)
    pv_cons = gke(d_H0_cons,d_cons);
  case "AS03" then	// Formula provided by Allen & Stott (2003)
    [bid,pv_cons] = cdff("PQ",d_cons/(N_red-I),N_red-I,NZ2);
  else
    pv_cons = %nan;
  end
end

// Main output: Beta_hat
Beta_hat = zeros(3,I);
Beta_hat = [beta_hat_inf; beta_hat; beta_hat_sup];
