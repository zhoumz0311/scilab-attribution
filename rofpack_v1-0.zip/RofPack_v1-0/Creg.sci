// Copyright:
//	Copyright (2012) Aur�lien Ribes, CNRM-GAME, M�t�o France - CNRS
// 
// Description:
//	This function compute the regularised covariance matrix estimate as introduced by Ledoit and Wolf (2003)
//
// References:
//	Ledoit O., M. Wolf (2004) A well-conditioned estimator for large-dimensional covariance matrices. Journal of Multivariate Analysis, 88(2): 365-411.
//	(thereafter : L&W)
//
// Input:
//	X, a n*p sample, meaning n iid realization of a random vector of size p.
//
// Output: 
//	Cr, a p*p matrix, the regularised covariance matrix estimate as introduced by Ledoit & Wolf.


function Cr = Creg(X)

[n,p] = size(X);
CE = X'*X/n;		// Sample covariance 

Ip = eye(p,p);
m = trace(CE * Ip) / p;	// First estimate in L&W
XP = CE - m * Ip;
d2 = trace(XP*XP')/p;	// Second estimate in L&W

for i=1:n
	Mi = (X(i,:))'*X(i,:);
	bt(i) = trace( (Mi-CE)*(Mi-CE)' ) /p;
end

bb2 = 1 / n^2 * sum(bt);
b2 = min(bb2,d2);	// Third estimate in L&W
a2 = d2-b2;		// Fourth estimate in L&W

Cr = b2*m/d2 * Ip + a2/d2 * CE;

endfunction
