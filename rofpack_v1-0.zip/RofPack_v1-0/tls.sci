// Copyright:
//	Copyritgh (2012) Aurélien Ribes, CNRM-GAME, Météo France - CNRS
// 
// Description:
//	This function performs a TLS fit.
//
// References:
//	Allen M.A. and P.A. Stott (2003) Estimating signal amplitude in optimal fingerprinting, part i: theory (thereafter AS03).
// 	Ribes A., S. Planton, L. Terray (2012) Regularised optimal fingerprint for attribution. Part I: method, properties and idealised analysis. Climate dynamics, submitted (thereafter, R12). 
//
// Inputs:
//	X, a n*k matrix, the k predictors (denoted x_tilde in R12),
//	Y, a n*1 vector, the observations,
//	Z2, a n*nz2 matrix, a set of independant realisations of internal variability,
//	nX, a k vector, the number of runs used for computing each columns of X,
//	Proj, a k*k matrix, the matrix that defined which forcings are used in each simulations (see Scientific documentation, Section 3.1)
//	Formule_IC_TLS, a string, the formula that will be used to compute the confidence intervals; "AS03" is recommended, the alternative ("ODP") is maintained for consistency with previous scripts. 
//
// Output: 
//	beta_hat, a k vector, the scaling factors best-estimates,
//	beta_hat_inf, a k vector, the lower bound of the 1-D confidence interval on each scaling factor,
//	beta_hat_sup, a k vector, the upper bound of the 1-D confidence interval on each scaling factor,
//	d_cons, a real, the variable used in the residual consistency check,
//	[optionnaly] X_tilde, a n*k matrix, the reconstructed responses patterns (ie reconstructed by the TLS fit),
//	[optionnaly] Y_tilde, a n*1 vector, the reconstructed observations (ie reconstructed by the TLS fit).


function [beta_hat, beta_hat_inf, beta_hat_sup, d_cons, varargout] = tls(X, Y, Z2, nX, Proj, Formule_IC_TLS)


// Check sizes of X and Y
if size(X,2) ~= size(Y,2) then disp("Error in TLS: size of inputs X, Y."); return; end
n = size(Y,2);
m = size(X,1);

// Normalise the variance of X
X =  X .* (sqrt(nX)'*ones(1,n));
DnX = diag(sqrt(nX));


// Computation of beta_hat
//--------------------------

// TLS fit via svd...
M = [X;Y];
[U D V] = svd(M);
// Consider the "smallest" singular vector
Uk = (U(:,$));
Uk_proj = [Proj*DnX*Uk(1:($-1)); Uk($)];
// Computes beta_hat
beta_hat = - Uk_proj(1:($-1)) ./ Uk_proj($);



// VARARGOUT  (ie optional outputs)
//----------------------------------

// Reconstructed data
D_tilde=D; D_tilde(m+1,m+1)=0;
Z_tilde = U * D_tilde * V';	
varargout(1) = Z_tilde(1:m,:) ./ (sqrt(nX)'*ones(1,n));	// X_tilde
varargout(2) = Z_tilde(m+1,:);				// Y_tilde



// Computation of Confidence Intervals
//--------------------------------------

d = diag(D).^2;	// The square singular values (denoted by lambda in AS03)

// Computation of corrected singular value (cf Eq 34 in AS03)
d_hat = zeros(d);
NAZv = size(Z2,1);
for i=1:length(d)
  vi = V(:,i)';
  select Formule_IC_TLS
  case "AS03" then
    d_hat(i) = d(i) / (vi * Z2'*Z2/NAZv * vi');	// Formule Allen & Stott (2003).
  case "ODP" then
    d_hat(i) = d(i) / ((vi.^2)*sum(Z2.^2,'r')'/NAZv);	// Formule ODP (Allen, Stone, etc).
  else 
    disp("tls_v1.sci : unknown formula for computation of TLS CI.")
  end
end

// The "last" corrected singular value will be used in the Residual Consistency Check
d_cons = d_hat($);


// Threshold of the Fisher distribution, used for CI computation (cf Eq 36-37 in AS03)
seuil_1d = sqrt(cdff("F",1,NAZv,.90,.10));

// In order to compute CI, we need to run through the m-sphere (cf Eq 30 in AS03, and explanations above)
// Here, npt points on the sphere are taken randomly
npt = 100000;	// Nb of pts on the (m-)sphère...
if m==1 then Pts=[1 ; -1];
else
  Pts_R = grand(npt,m,"nor",0,1);
  Pts = Pts_R ./ (sqrt(sum(Pts_R.^2,2))*ones(1,m));	// The points on the sphere
end


delta_d_hat = d_hat - min(d_hat);	// delta_d_hat provides the diagonal of the matrix used in Eq 36 in AS03
a = seuil_1d * Pts;			// following notation of Eq 30 in AS03
if ~sum(delta_d_hat(1:($-1))==0) then	// Check that 0 is not reached before the last index of delta_d_hat
  b_m1 = a ./ (ones(Pts(:,1))*sqrt(delta_d_hat(1:($-1)))');
  b_m2 = sqrt( 1 - sum(b_m1.^2,2) );	// following notation of Eq 31 in AS03
else					// If 0 is reached before last index of delta_d_hat, the CI will be unbounded
  disp("Unbounded CI (1)");
  beta_hat_inf = zeros(beta_hat)+%nan;
  beta_hat_sup = zeros(beta_hat)+%nan;
  return;
end

// b_m2 need to be strctly positive, otherwise the CI will be unbounded
if ~prod(isreal(b_m2)) | sum(b_m2==0) then
  disp("Unbounded CI (2)");  disp(max(imag(b_m2)));
  beta_hat_inf = zeros(beta_hat)+%nan;
  beta_hat_sup = zeros(beta_hat)+%nan;
else
// Then in order to CI that include +/- infinity, the computation are made in terms of angles, based on complex numbers (this is a descrepancy with ODP)
// This part is more technical and not commented at the moment. If you have questions, please contact me.
  V_pts = [b_m1 b_m2]*U';
  V_pts_proj = [V_pts(:,1:($-1)) *DnX* Proj', V_pts(:,$)];
  for i=1:m
    Vc_2d_pts = V_pts_proj(:,i) + %i * V_pts_proj(:,$);
    Vc_2d_ref = Uk_proj(i) + %i * Uk_proj($);
    Vprod_2d = Vc_2d_pts / Vc_2d_ref;
    arg = gsort(imag(log(Vprod_2d)),'g','i');
    delta_arg_min = arg(1);
    delta_arg_max = arg($);
    [Delta_max_1, k1] = max(arg(2:$)-arg(1:($-1)));
    [Delta_max  , k2] = max( Delta_max_1, arg(1)-arg($)+2*%pi);
    if Delta_max<%pi then
	beta_hat_inf(i) = %nan;
	beta_hat_sup(i) = %nan;
    else
	if k2~=2 then disp("Warning k2"); end
	arg_ref = imag(log(Vc_2d_ref));
	arg_min = delta_arg_min + arg_ref;
	arg_max = delta_arg_max + arg_ref;
	beta_hat_inf(i) = -1/tan(arg_min);
	beta_hat_sup(i) = -1/tan(arg_max);
    end
  end
end


endfunction
