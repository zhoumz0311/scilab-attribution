// Copyright :
//	Copyritgh (2012) Aurélien Ribes, CNRM-GAME, Météo France - CNRS
// 
// Description :
//	This function provides the total wave number corresponding to each index of Y.
//
// Input :
//	n, an integer, the truncation.
//
// Output : 
//	l, a vector of size (n+1)^2 (ie the number of real coefficients needed to describe a global field in truncation Tn), the total wave number of spherical harmonic corresponding to each index (see Scientific documentation, Section 1.2 and Table 1).


function l = total_wave_number(n)

nr = (n+1)^2;
l = zeros(nr,1);

ir = 1;
l(1:(n+1)) = (1:(n+1))';
ir = ir+n+1;
for i=2:(n+1)
 for j=i:(n+1)
  l([ir,ir+1]) = [j;j];
  ir = ir+2;
 end
end

endfunction
