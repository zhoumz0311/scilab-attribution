// Copyright :
//	Copyritgh (2012) Aurélien Ribes, CNRM-GAME, Météo France - CNRS
// 
// Description :
//	This function simulates a sample of N iid random variables (Monte-Carlo simulations) following the null-distribution of the Residual Consistency Check (RCC, see References below), based on real-world parameters (see inputs).
//
// References :
//	Allen M.A. and P.A. Stott (2003) Estimating signal amplitude in optimal fingerprinting, part i: theory (thereafter AS03).
// 	Ribes A., S. Planton, L. Terray (2012) Regularised optimal fingerprint for attribution. Part I: method, properties and idealised analysis. Climate dynamics, submitted (thereafter R12). 
//
// Inputs :
//	- Sigma, a n*n matrix, the "true" covariance matrix of internal variability. Practically, the covariance matrix estimated by ROF is used as Sigma.
//	- X0, a n*I matrix, the "true" predictors (ie response patterns) used in the regression equation. From X0, virtual outputs of climate models (X) will be simulated by adding inernal variability. Practically, the response patterns from the main scripts are used as X0.
//	- nb_runs_X, a I vector, the number of runs used for evaluating each response pattern X,
//	- n1, an integer, the size of sample Z1,
//	- n2, an integer, the size of sample Z2,
//	- N, an integer, the number of MC simulations,
//	- Formula, a string, the formula to be used for computing the RCC variable. This one may be:
//		"AS03": the formula provided in AS03,
//		"ODP": the formula implemented in the Optimal Detection Package (in Nov 2011).
//
// Output : 
//	d_cons_H0, a vector of size N, a sample of N iid random variables following the null-distribution of the Residual Consistency Check. 


function d_cons_H0 = consist_mc_tls(Sigma, X0, nb_runs_X, n1, n2, N, Formula)

// Check that Sigma is a square matrix
n = size(Sigma,'r');
if size(Sigma,'c')~=n | size(X0,'r')~=n then 
  disp("Error of size in consist_mc_tls.sci"); return
end

// Number of external forcings considered
k = size(X0,'c');

// Initial value of beta for the Monte Carlo simulations
beta0 = ones(k,1);


// Monte Carlo simulations
//-------------------------
Sigma12 = Sigma^(1/2);
d_cons_H0 = zeros(N,1);

for i=1:N
 // Virtual observations Y
 Yt = X0*beta0;
 Y = Yt + Sigma12*grand(n,1,'nor',0,1);
 // Virtual noised response patterns X
 X = X0 + Sigma12*grand(n,k,'nor',0,1)./(ones(Yt)*sqrt(nb_runs_X));
 // Variance normalised X
 Xc = (ones(Yt)*sqrt(nb_runs_X)) .* X;
 // Virtual independent samples of pure internal variability, Z1 and Z2
 Z1 = Sigma12 * grand(n,n1,"nor",0,1);
 Z2 = Sigma12 * grand(n,n2,"nor",0,1);
 // Virtual estimated covariance matrix (based on Z1 only)
 C1_hat = Creg(Z1');
 C12 = C1_hat^(-1/2);

 // The following emulates the TLS algorithm and computes the variable used in the RCC (which is written in d_cons_H0). See also tls_v1.sci.
 M = C12*[Xc,Y];	// Xc and Y are prewhitened
 [U,D,V] = svd(M');
 d = diag(D).^2;
 nd = length(d);
 vi = V(:,nd)';
 select Formula
 case "AS03" then
  Z2w = (C12*Z2)';	// Z2 is prewhitened
  d_cons_H0(i) = d(nd) / (vi * Z2w'*Z2w/n2 * vi');
 case "ODP" then
  Z2w = (C12*Z2)';	// Z2 is prewhitened
  d_cons_H0(i) = d(nd) / ((vi.^2)*sum(Z2w.^2,'r')'/n2);
 else
  disp("consist_mc_tls.sci : unknown formula for computation of RCC.");
 end
end

return d_cons_H0
