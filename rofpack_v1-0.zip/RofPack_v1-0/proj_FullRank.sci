// Copyright :
//	Copyritgh (2012) Aurélien Ribes, CNRM-GAME, Météo France - CNRS
// 
// Description :
//	This function provides a projection matrix that can be applied to Y to ensure its covariance matrix to be full-ranked (see online scientific documentation).
//	The function is designed to be applied to spatio-temporal data. 
//
// References :
//	Online scientific documentation.
// 	Ribes A., S. Planton, L. Terray (2012) Regularised optimal fingerprint for attribution. Part I: method, properties and idealised analysis. Climate dynamics, submitted. 
//
// Input :
//	T, an integer: the temporal dimension (ie the number of time-steps considered in the ROF algorithm),
//	S, an integer: the spatial dimension (ie the number of spatial locations or coefficients considered in the ROF algorithm).
//
// Output : 
//	P, a [ (T-1)*S x T*S ] matrix, the projection matrix.
//
// Note : The projection matrix P is derived from the eigenvectors of the matrix M (M defines the temporal centering, see below), which is assumed to have been previously applied to Y (as a consequence, Y is such as M*Y=Y).


function P = proj_FullRank(T, S)

// M: the matrix corresponding to the temporal centering
M = eye(T,T) - ones(T,T)/T;
// Eigen-values/-vectors of M; note that rk(M)=T-1, so M has one eigenvalue equal to 0.
[u,d] = speco(M);
// (T-1) first eigenvectors (ie the ones corresponding to non-zero eigenvalues)
U = u(:,1:(T-1))';

// The projection matrix P, which consists in S replications of U.
P = zeros((T-1)*S,T*S);
for i=1:S
  P(i:S:((T-1)*S),i:S:(T*S)) = U;
end

endfunction
