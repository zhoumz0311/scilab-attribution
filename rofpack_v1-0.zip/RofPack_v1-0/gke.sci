// Copyright :
//	Copyritgh (2012) Aurélien Ribes, CNRM-GAME, Météo France - CNRS
// 
// Description : gke, Gaussian Kernel Estimate
//	This function estimate the "(1-quantile)" (or for hypothesis testing, the p-value) of a distribution, from a sample of independent random variables following this distribution.
//
// Inputs :
//	d_H0, a n vector, the sample of independent realisation following the investigated distribution.
//	d, a real, the value at which the quantile has to be estimated
//
// Output : 
//	pv, a real, the "(1-quantile)" value estimated (or, for hypothesis testing, the p-value).


function pv = gke(d_H0,d)

N = length(d_H0);
h = 1.06*stdev(d_H0)*N^(-1/5);	// Silverman's rule of Thumb
[onem,pvi] = cdfnor("PQ",d*ones(d_H0),d_H0,h*ones(d_H0));
pv = sum(pvi)/N;

return pv

endfunction
