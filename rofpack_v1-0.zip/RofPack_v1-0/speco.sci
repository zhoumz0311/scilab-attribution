// Copyright :
//	Copyritgh (2012) Aurélien Ribes, CNRM-GAME, Météo France - CNRS
// 
// Description :
//	This function computes eigenvalues and eigenvectors, in descending order. 
//
// Input :
//	C, a p*p symetric real matrix.
//
// Output : 
//	P, a p*p matrix: the eigenvectors (P(:,i) is the ist eigenvector),
//	D, a p*p diagonal matrix: the eigenvalues.
//	[optionnaly] Do, a p-vector: the sorted eigenvalues.


function [P,D,varargout] = speco(C)


// Compute eigenvalues and eigenvectors
[P0,D0] = spec(C);

// Take real part (to avoid numeric noise, eg small complex numbers)
if max(imag(D0))/max(real(D0)) > 10^(-12) then disp("Pb dans speco : matrice non symétrique"); return; end

// Check that C is symetric (<=> real eigen-values/-vectors)
P1 = real(P0);
D1 = real(diag(D0));

// Sort in a descending order
[Do,o] = gsort(D1,'r','d');
P = P1(:,o);
D = diag(Do);

varargout(1) = Do;

endfunction
