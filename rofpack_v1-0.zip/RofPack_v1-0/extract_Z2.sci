// Copyright :
//	Copyritgh (2012) Aur�lien Ribes, CNRM-GAME, M�t�o France - CNRS
// 
// Description :
//	This function is used to split a big sample Z (dimension: NZ*p, containing NZ iid realisation of a random vector of size p) into two samples Z1 and Z2 (respectively of dimension n1*p and n2*p, with NZ=n1+n2). Further explanations in Ribes et al. (2012).
//
// References :
// 	Ribes A., S. Planton, L. Terray (2012) Regularised optimal fingerprint for attribution. Part I: method, properties and idealised analysis. Climate dynamics, submitted. 
//
// Inputs :
//	- sampling_name: type of sampling used ; may be:
//		'random'  (purely random),
//		'regular' (eg, one vector out of two), [recommended for reproducibility]
//		'segment' (eg, the first n2 vectors in Z).
//	- NZ: number of available iid realisations (in Z).
//	- frac_Z2: fraction of realisation to put in Z2. The remaining will be used in Z1 (ie frac_Z1 = 1-frac_Z2).
//
// Output : 
//	Ind_Zv : A boolean vector of size NZ, that indicates the vectors that will be used in Z1 ("F") or Z2 ("T").


function Ind_Z2 = extract_Z2 (sampling_name, NZ, frac_Z2)

Ind_Z2 = zeros(NZ,1);
NZ2 = floor(NZ * frac_Z2)

select sampling_name
case "segment" then
	Ind_Z2(1:NZ2) = 1;
	disp("      Z2 : segment 1-"+string(NZ2)+", fraction ~ "+string(NZ2/NZ));
case "regular" then
	ix = floor( (1/frac_Z2):(1/frac_Z2):NZ );
//	ix = floor( 1:(1/frac_Z2):NZ );
	Ind_Z2(ix) = 1;
	disp("      Z2 : regular, fraction ~ "+string(sum(Ind_Z2)/NZ));
case "random" then
	u = grand(NZ,1,'nor',0,1);
	[not,z] = gsort(u);
	Ind_Z2(z(1:NZ2)) = 1;
	disp("      Z2 : random, fraction ~ "+string(sum(Ind_Z2)/NZ));
else
	disp("      ==> unknown sampling_name (extract_Z2.sci)");
end

endfunction
